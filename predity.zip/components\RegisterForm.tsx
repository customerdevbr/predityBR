"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Mail, Lock, ArrowRight, User, Eye, EyeOff, Calendar, CreditCard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';

export default function RegisterForm() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [fullName, setFullName] = useState('');
    const [cpf, setCpf] = useState('');
    const [dob, setDob] = useState('');
    const [acceptedTerms, setAcceptedTerms] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    // CPF auto-mask: formats as 000.000.000-00
    const formatCpf = (value: string) => {
        const digits = value.replace(/\D/g, '').slice(0, 11);
        if (digits.length <= 3) return digits;
        if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
        if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
        return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
    };

    const handleRegister = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        if (!fullName || !cpf || !dob || !email || !password || !confirmPassword) {
            setError("Todos os campos são obrigatórios.");
            setLoading(false);
            return;
        }

        if (!acceptedTerms) {
            setError("Você deve concordar com os Termos para criar uma conta.");
            setLoading(false);
            return;
        }

        if (password !== confirmPassword) {
            setError("As senhas não coincidem.");
            setLoading(false);
            return;
        }

        if (!cpf || cpf.length < 11) {
            setError("CPF inválido.");
            setLoading(false);
            return;
        }

        try {
            const cleanCpf = cpf.replace(/\D/g, '');

            const { data, error } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    data: {
                        full_name: fullName,
                        cpf: cleanCpf,
                        dob: dob,
                        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
                    },
                },
            });

            if (error) throw error;

            // Also write CPF and DOB directly to the public.users table
            // The trigger may not always run synchronously, so we force-write these values
            if (data.user) {
                // Check for referral code in localStorage
                let referredByCode: string | null = null;
                try {
                    const stored = localStorage.getItem('predity_ref');
                    if (stored) {
                        const parsed = JSON.parse(stored);
                        if (parsed.expires > Date.now()) {
                            referredByCode = parsed.code;
                        } else {
                            localStorage.removeItem('predity_ref');
                        }
                    }
                } catch { }

                // Find the referrer
                let referrerId: string | null = null;
                if (referredByCode) {
                    const { data: referrer } = await supabase
                        .from('users')
                        .select('id')
                        .eq('referral_code', referredByCode)
                        .single();
                    if (referrer) referrerId = referrer.id;
                }

                await supabase
                    .from('users')
                    .upsert({
                        id: data.user.id,
                        email,
                        full_name: fullName,
                        cpf: cleanCpf,
                        dob,
                        ...(referrerId ? { referred_by: referrerId } : {}),
                    }, { onConflict: 'id' });

                // Clear ref cookie after use
                if (referredByCode) localStorage.removeItem('predity_ref');
            }

            alert('Cadastro realizado! Verifique seu email para confirmar.');
            router.push('/login');
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-surface border border-surface rounded-xl p-8 space-y-6 shadow-2xl relative z-10">
            <div className="text-center space-y-2">
                <h1 className="text-2xl font-bold">Criar Conta</h1>
                <p className="text-gray-400 text-sm">Junte-se a milhares de participantes</p>
            </div>

            {error && (
                <div className="bg-red-500/10 border border-red-500/50 text-red-500 text-sm p-3 rounded-lg text-center">
                    {error}
                </div>
            )}

            <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">Nome Completo</label>
                    <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type="text"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary transition-all"
                            placeholder="Seu Nome"
                            required
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">CPF</label>
                    <div className="relative">
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type="text"
                            value={cpf}
                            onChange={(e) => setCpf(formatCpf(e.target.value))}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary transition-all"
                            placeholder="000.000.000-00"
                            maxLength={14}
                            required
                        />
                    </div>
                    <p className="text-[10px] text-gray-500">IMPORTANTE: Entradas e saídas via PIX devem ser do mesmo titular e CPF.</p>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">Data de Nascimento</label>
                    <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type="date"
                            value={dob}
                            onChange={(e) => setDob(e.target.value)}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary transition-all [color-scheme:dark]"
                            required
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">Email</label>
                    <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-primary transition-all"
                            placeholder="seu@email.com"
                            required
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">Senha</label>
                    <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type={showPassword ? "text" : "password"}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-12 py-3 text-white focus:outline-none focus:border-primary transition-all"
                            placeholder="••••••••"
                            required
                            minLength={6}
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
                        >
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                    </div>
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase">Confirmar Senha</label>
                    <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                        <input
                            type={showConfirmPassword ? "text" : "password"}
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full bg-black/40 border border-surface rounded-lg pl-10 pr-12 py-3 text-white focus:outline-none focus:border-primary transition-all"
                            placeholder="••••••••"
                            required
                            minLength={6}
                        />
                        <button
                            type="button"
                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
                        >
                            {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                    </div>
                </div>

                <div className="space-y-4 pt-2 border-t border-white/5">
                    <label className="flex items-start gap-3 cursor-pointer group">
                        <div className="relative flex items-center justify-center w-5 h-5 mt-0.5 flex-shrink-0">
                            <input
                                type="checkbox"
                                checked={acceptedTerms}
                                onChange={(e) => setAcceptedTerms(e.target.checked)}
                                className="peer appearance-none w-5 h-5 border-2 border-gray-600 rounded bg-black/40 checked:bg-primary checked:border-primary transition-all cursor-pointer"
                            />
                            <div className="absolute text-white opacity-0 peer-checked:opacity-100 pointer-events-none">
                                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            </div>
                        </div>
                        <span className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors leading-relaxed">
                            Declaro que tenho mais de 18 anos e li e concordo com os <Link href="/kyc" target="_blank" className="text-primary hover:underline font-bold">Termos KYC</Link>, <Link href="/privacy" target="_blank" className="text-primary hover:underline font-bold">Privacidade</Link> e <Link href="/legal" target="_blank" className="text-primary hover:underline font-bold">Segurança Jurídica</Link>.
                        </span>
                    </label>

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-3 bg-primary hover:bg-primary/90 hover:scale-[1.02] active:scale-[0.98] text-white rounded-lg font-bold shadow-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50 disabled:hover:scale-100"
                    >
                        {loading ? 'Criando conta...' : 'Registrar'} <ArrowRight className="w-4 h-4" />
                    </button>

                    <div className="bg-surface/50 border border-white/5 rounded-lg p-3 text-center mb-4 mt-2">
                        <p className="text-xs text-gray-400 leading-relaxed">
                            Esteja atento aos riscos de dependência. Em caso de dúvida, consulte nossa área de <Link href="/responsible" target="_blank" className="text-primary hover:underline">Jogo Responsável</Link>.
                        </p>
                    </div>
                </div>
            </form>

            <div className="text-center text-sm text-gray-400">
                Já tem uma conta? <Link href="/login" className="text-primary hover:underline">Fazer login</Link>
            </div>
        </div>
    );
}
